<?php
include 'part/header.php';
include 'koneksi.php';
if (empty($_SESSION['tipe'] == "Admin")) {
header("Location:index.php?pesan=user_auth"); // jika belum login, maka dikembalikan ke file index.php
}else{
$salon_id = $_GET["salon_id"];
$query = mysqli_query($mysqli,"SELECT * FROM pemesanan WHERE salon_id='$salon_id'");

?>

<div class="container">
	<div class="row">
		<div class="box box-solid bg-green">
			<div class="box-header">
            <h1 class="glyphicon glyphicon-shopping-cart text-bold mb-5 pb-3"></hi><span>RECORD</span> </h1>
			<div class="box-body">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>ID PAKET</th>
							<th>ID PRODUK</th>
							<th>JUMLAH PEMBAYARAN</th>
							<th>WAKTU BOOKING</th>
							<th>JAM</th>
						</tr>
					</thead>
					<tbody>
					<?php
							while($user_data = mysqli_fetch_array($query)) {
												echo "<td>".$user_data['id_paket']."</td>";
												echo "<td>".$user_data['id_produk']."</td>";
												echo "<td>".$user_data['jumlah_pembayaran']."</td>";
                                                echo "<td>".$user_data['waktu_booking']."</td>";
                                                echo "<td>".$user_data['jam']."</td>";
						echo "</tr>";
					}
					?>
				</tbody>
				
			</table>
		</div>
	</div>
</div>
</div>

</form>
<?php
}
include 'part/footer.php';
?>