<head>
<?php
include 'part/header.php';
include 'koneksi.php';
if (empty($_SESSION['tipe'] == "")) {
	header("location:index.php?pesan=user_auth"); // jika belum login, maka dikembalikan ke file index.php
	}
	else {
	// Load data dari tabel
	$result = mysqli_query($mysqli, "SELECT * FROM jenistreathment ORDER BY id_jt");
	}
?>
<!-- Stylesheets -->
	<!-- <link rel="stylesheet" href="css/bootstrap.min.css"/> -->
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/jquery-ui.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>

<section class="hero-section set-bg" data-setbg="img/bg.jpg" >

<div class="container">

<div class="row">
	<div class="box" style="background-color: rgb(252, 182, 193);">
		<div class="box-header" style="background-color: rgb(249, 19, 147);">
			<h4>Tentang Kami</h4>
		</div>
		<div class="box-body">
		
<br>
Transaksi pembelian yang telah dilakukan setelah uang dikirimkan tidak dapat dibatalkan. Transaksi yang Anda lakukan telah menjalani proses pengemasan dan pengiriman yang tidak mungkin dibatalkan. Namun jika pesanan yang Anda terima tidak sesuai, Dammai.com menyediakan fasilitas pengembalian barang atau return. Syarat dan ketentuan mengenai pengembalian barang dapat dilihat lebih lengkap di bagian Pengembalian Barang.

<br>

<b>Pembayaran</b>
<br>
Pembayaran setiap transaksi yang dilakukan di Dammai.com harus dilakukan dalam jangka waktu 1×24 jam. Terhitung mulai booking pada barang dilakukan atau sesaat setelah Anda menekan tombol Check Out. Jika selama jangka waktu pembayaran tersebut, Anda tidak melakukan pembayaran, maka booking atau pesanan akan dibatalkan. Barang yang telah dipesan akan dikembalikan lagi ke dalam sistem. Barang akan dapat dibeli oleh pembeli lainnya.
<br>

<b>Bank Transfer</b>
<br>
Jika pembayaran dilakukan pada Bank Transfer, Anda harus melakukan konfirmasi melalui Confirm Payment pada website resmi Dammai.com. Konfirmasi pembayaran harus dilakukan maksimal 2 jam setelah pembayaran dilakukan pada hari dan jam kerja. Setiap konfirmasi yang Anda lakukan akan segera ditindaklanjuti Dammai.com dengan melakukan proses pengiriman produk pesanan Anda pada hari berikutnya.

		</p>
		</div>


<section class="timetable-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<h2 class="ts-title">Quick Info</h2>
					<div id="accordion" class="accordion-area about-accordion">
					<div class="panel-header" id="headingOne">
							<?php
							while($user_data = mysqli_fetch_array($result)) {
								echo "<tr>";
								
					?>
						<div class="panel">
							<div class="panel-header" id="headingOne">
								<button class="panel-link" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapse1"><?php echo $user_data['nama_jt']?></button>
							</div>
							<div id="collapse1" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
								<div class="panel-body">
									<p><?php echo $user_data['keterangan']?></p>
								</div>
							</div>
						</div>
						<?php
							}
						?>
					</div>
					</div>
				</div>
				<div class="col-lg-6">
					<h2 class="ts-title">Opening Hours</h2>
					<div class="timetable-card">
						<img src="img/clock.png" alt="">
						<ul>
							<li><span>SELASA, RABU, KAMIS:</span>09.00-19.00</li>
							<li><span>JUM'AT:</span>10.00-19.00</li>
							<li><span>SABTU, MINGGU:</span>08.00-19.00</li>
							<li><span>SENIN:</span>Closed</li>
						</ul>
						<a href="https://api.whatsapp.com/send?phone=6287851097999" class="site-btn">KONTAK WHATSAPP</a>
					</div>
				</div>
		
	</section>
	<!--  timetable section end -->


	<!-- Services section end -->

	

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>

    </body>
</html>