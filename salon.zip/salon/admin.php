

<!-- <!DOCTYPE html>
<html lang="zxx"> -->
<head>
	<!-- <title>Diva - Beauty salon template</title>
	<meta charset="UTF-8">
	<meta name="description" content="Diva Beauty salon template">
	<meta name="keywords" content="diva, beauty, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
	<!-- Favicon -->   
	<!-- <link href="img/favicon.ico" rel="shortcut icon"/> -->

    <?php
include 'part/header.php';
include 'koneksi.php';
if (empty($_SESSION['tipe'] == "Admin")) {
header("location:index.php?pesan=user_auth"); // jika belum login, maka dikembalikan ke file index.php
}
else {
	// Load data dari tabel
	$result = mysqli_query($mysqli, "SELECT * FROM pembayaran");
$num = mysqli_num_rows($result);
	}
	?>
	<!-- Stylesheets -->
	<!-- <link rel="stylesheet" href="css/bootstrap.min.css"/> -->
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/jquery-ui.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet"  href=
    "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="
    sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" 
    crossorigin="anonymous"></script>
</head>
<body>
	<!-- Page Preloder -->
	
  
	<!-- Services section -->
	<section class="services-section spad set-bg" data-setbg="img/bg.jpg">
		<div class="container">
			<div class="section-title text-white">
				<center><h2>DASBORT ADMIN</h2></center>
			</div>
			<div class="row">
				<!-- service -->
				<div class="col-lg-4 col-md-6 service text-white">
					
					<i class="flaticon-009-makeup-5"></i>
					<h2>JENIS PRODUK</h2>
					<p>Anda Dapat Mengedit Data Jenis Produk Disini</p>
					<a class='btn site-btn' href='jenisproduk.php'> Pilih</a>
				</div>
				<!-- service -->
				<div class="col-lg-4 col-md-6 service text-white">
					<i class="flaticon-017-soap"></i>
					<h2>PRODUK</h2>
					<p>Anda Dapat Mengedit Data Produk Disini</p>
					<a class='btn site-btn' href='produk.php'> Pilih</a>
				</div>
				<!-- service -->
				<div class="col-lg-4 col-md-6 service text-white">
				<i class="flaticon-048-makeup"></i>
					<!-- <i class="flaticon-009-makeup-5"></i> -->
					<h2>JENIS TREATHMENT</h2>
					<p>Anda Dapat Mengedit Data Jenis Treathment Disini</p>
					<a class='btn site-btn' href='jenistreathment.php'> Pilih</a>
				</div>
				<!-- service -->
				<div class="col-lg-4 col-md-6 service text-white">
					<i class="flaticon-016-woman"></i>
					<h2>TREATHMENT</h2>
					<p>Anda Dapat Mengedit Data Treathment Disini</p>
					<a class='btn site-btn' href='treathment.php'> Pilih</a>
				</div>
				<!-- service -->
				<div class="col-lg-4 col-md-6 service text-white">
					<i class="flaticon-045-eyelid"></i>
					<h2>PEMESANAN</h2>
					<p>Anda Dapat Mengedit Data Pemesanan Disini</p>
					<a class='btn site-btn' href='pemesanan.php'> Pilih</a>
				</div>
				<!-- service -->
				<div class="col-lg-4 col-md-6 service text-white">
					<i class="flaticon-015-facial-mask"></i>
					<h2>PEMBAYARAN  <span class="badge badge-pill badge-danger"><?php echo $num?> </span></h2>
					<p>Anda Dapat Mengedit Data Pembayran Disini</p>
					<a class='btn site-btn' href='pembayaran.php'> Pilih</a>
				</div>
			</div>
		</div>
	</section>
	<!-- Services section end -->

	

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>

    </body>
</html>